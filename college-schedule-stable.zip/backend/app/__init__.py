"""College Schedule backend application."""
