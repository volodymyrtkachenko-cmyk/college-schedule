"""Core application utilities."""
